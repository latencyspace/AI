from appJar import gui

def press(button):
    app.stop()

app = gui()
app.addLabel("title", "Hello World")
app.addButton("Quit", press)
app.go()